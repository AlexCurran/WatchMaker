WatchMaker Sample Watch Pack

Full information on Watch Packs is available here:
http://watchmaker.haz.wiki/apk