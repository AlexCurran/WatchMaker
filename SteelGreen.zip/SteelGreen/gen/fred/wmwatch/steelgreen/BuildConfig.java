/** Automatically generated file. DO NOT MODIFY */
package fred.wmwatch.steelgreen;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}